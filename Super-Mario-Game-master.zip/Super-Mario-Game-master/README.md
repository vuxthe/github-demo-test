# MarioPygame
# Python Programming

# By techprogrammer007
## techprogrammer007@gmail.com

## Follow on instagram @code_with_python_
## Starting
Install these python libraries:
```
pip install pygame
pip install pytmx
```

 Then execute 'Next/main.py'. 

